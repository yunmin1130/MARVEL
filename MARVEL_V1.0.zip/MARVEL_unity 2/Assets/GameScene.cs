﻿#region Using Statements
using MarkLight.Examples.Data;
using MarkLight.Views.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
#endregion

namespace MarkLight.Examples.UI
{
	/// <summary>
	/// Example demonstrating a game menu.
	/// </summary>
	public class GameScene : View
	{
		public void BackToMainMenu(){
			GameObject.Destroy (GameObject.FindWithTag ("option_setting"));
			SceneManager.LoadScene("GameMenuExample");
		}

		public void RollDice(){
			GameObject.Find ("rolling_dice").GetComponent<rolldice> ().Start ();
		}

		public void GoUnityChan(){
			GameObject.Find ("unitychan").GetComponent<Unitychan_Control> ().dice_num_Update ();
		}
	}
}


﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MarkLight.Examples.UI;

public class game_option_setting : MonoBehaviour {

	// Use this for initialization

	public GameMenuExample option_setting;

	void Start () {
		option_setting = GameObject.Find ("GameMenuExample").GetComponent<GameMenuExample>();
		DontDestroyOnLoad (this);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unitychan_Control : MonoBehaviour {

	private Animator animator;
	private bool shouldMove = false;
	private bool shouldrotate = false;

	int rotate_count = 0;

	int pass_num = 0;
	int dice_num = 0;

	// Use this for initialization

	void Start () {
		animator = GetComponent<Animator> ();
		shouldMove = false;
		animator.SetBool ("running", false);
	}

	// Update is called once per frame
	void FixedUpdate () {	
		if (rotate_count == 1) { // inital start collision pass check
			shouldrotate = false;
		}
		if (shouldrotate) {
			transform.Rotate (90*Vector3.down);
			shouldrotate = false;
		}
		else if (shouldMove) {
			if (pass_num < dice_num ) {
				transform.Translate (Vector3.forward * Time.deltaTime * (transform.localScale.x * .3f));
			}
			else {
				shouldMove = false;
				animator.SetBool ("running", false);
				pass_num = 0;
				dice_num = 0;
			}
		}

	}
	public void dice_num_Update() {
		dice_num = Dice0_script.Instance.GetDiceCount () + Dice1_script.Instance.GetDiceCount ();
		shouldMove = true;
		//dice_num = 1000;
		animator.SetBool ("running", true);
		pass_num = 0;
	}

	void OnCollisionEnter(Collision coll) {
		if (coll.collider.tag.Equals ("blockrotate")) {
			rotate_count++;
			shouldrotate = true;
		}
	}
	void OnCollisionExit(Collision coll) {
		if (coll.collider.tag.Equals ("pass_check")) {
			pass_num++;
			if (pass_num > dice_num) {
				shouldMove = false;
				animator.SetBool ("running", false);
				pass_num = 0;
				dice_num = 0;
			}
			Debug.Log (pass_num);	
		}
	}
}

﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using MarkLight.Examples.Data;
using MarkLight.Views.UI;
using MarkLight.Examples.UI;

public class rolldice : MonoBehaviour
{

	// Static Instance of the Dice
	public static rolldice Instance;
	#region Public Variables
	// get for game object 
	// public variable

	public GameObject Dice0;
	public GameObject Dice1;
	public GameObject board;
	public bool isDiceThrowable = true;
	#endregion
	// private variable;

	private static float size;
	private int diceCount0 = 0;
	private int diceCount1 = 0;
	private Vector3 dice0_past_rotation;
	private Vector3 dice1_past_rotation;

	public void Start (){	
		// with button click this method will begin
		// during this method gamer can't roll the dice again and this will be controlled by isDiceThrowable

		if (isDiceThrowable) {
			get_ready_for_roll ();

			StartCoroutine (getDiceCount ());
			isDiceThrowable = true;
		}
	}

	private bool is_dice_stop(){
		// check for the dice is stop
		// if dice stop it return false if not will return true

		if ((Vector3.Dot (dice0_past_rotation.normalized, Dice0.transform.rotation.eulerAngles.normalized) > 0.999f)
		   && (Dice0.transform.position.y - board.transform.position.y < 0.014f)
			&& (Vector3.Dot (dice1_past_rotation.normalized, Dice1.transform.rotation.eulerAngles.normalized) > 0.999f)
		   && (Dice1.transform.position.y - board.transform.position.y) < 0.014f) {
			return false;
		}
		return true;
	}

	void get_ready_for_roll(){
		// setting before rolling dice
		// the dice0 and dice1 rotate randomly and add torque and force also so the dice will get number randomly

		isDiceThrowable = false;
		size = board.transform.localScale.x;
		Vector3 new_position = board.transform.position + new Vector3 (1.0f, 5.0f, 1.0f) * size;
		Vector3 dice_direction = new Vector3 (Random.Range (-5, 5), Random.Range (0, 5), Random.Range (-5, 5));
		Dice0.transform.position = new_position;
		Dice0.GetComponent<Rigidbody> ().AddTorque (new Vector3 (Random.Range (-5, 5), Random.Range (-5, 5), Random.Range (-5, 5)).normalized * Random.Range(100,600), ForceMode.Impulse);
		Dice0.GetComponent<Rigidbody> ().AddForce (dice_direction.normalized * Random.Range (20, 40));

		new_position = board.transform.position + new Vector3 (-1.0f, 5.0f, -1.0f) * size;
		dice_direction = new Vector3 (Random.Range (-5, 5), Random.Range (0, 5), Random.Range (-5, 5));
		Dice1.transform.position = new_position;
		Dice1.GetComponent<Rigidbody> ().AddTorque (new Vector3 (Random.Range (-5, 5), Random.Range (-5, 5), Random.Range (-5, 5)).normalized * Random.Range(100,600), ForceMode.Impulse);
		Dice1.GetComponent<Rigidbody> ().AddForce (dice_direction.normalized * Random.Range (20, 40));
		Physics.gravity = new Vector3 (0.0f, -2.0f, 0.0f);
		StartCoroutine (randomrotate ());
	}

	public void get_dicenumber(){
		// if dice stop programer can get the numbers by this method
		// this method will return the number

		diceCount0 = Dice0_script.Instance.GetDiceCount ();
		diceCount1 = Dice1_script.Instance.GetDiceCount ();
	}

	IEnumerator randomrotate(){
		// rotate the dice randomly

		Dice0.transform.Rotate(new Vector3(Random.Range(0,180),Random.Range(0,180),Random.Range(0,180))); 
		Dice1.transform.Rotate(new Vector3(Random.Range(0,180),Random.Range(0,180),Random.Range(0,180))); 
		while ((Dice0.GetComponent<Rigidbody> ().velocity.magnitude < 0.1f) || (Dice1.GetComponent<Rigidbody> ().velocity.magnitude < 0.1f))
			yield return new WaitForSeconds(1.0f);
	}

	IEnumerator getDiceCount()
	{
		// check if dice is stopped and if dice stop it will get dicecount that dice show

		while (is_dice_stop()) {
			dice0_past_rotation = Dice0.transform.rotation.eulerAngles.normalized;
			dice1_past_rotation = Dice1.transform.rotation.eulerAngles.normalized;
			yield return new WaitForSeconds(1.0f);
		}
		diceCount0 = Dice0_script.Instance.GetDiceCount ();
		diceCount1 = Dice1_script.Instance.GetDiceCount ();
	}
}


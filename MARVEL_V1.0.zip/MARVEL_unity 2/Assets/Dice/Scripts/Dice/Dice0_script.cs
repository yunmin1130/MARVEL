﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dice0_script : MonoBehaviour {
	public int diceCount0;
	public static Dice0_script Instance;

	internal Vector3 initPos;
	// Use this for initialization
	void Start () {
		GetComponent<Rigidbody> ().solverIterations = 250;
		Instance = this;
		initPos = transform.position;
	}

	void OnEnable(){
		initPos = transform.position;
	}

	public int GetDiceCount(){
		diceCount0 = 0;
		regularDiceCount ();
		return diceCount0;
	}

	void regularDiceCount()
	{
		if (Vector3.Dot (transform.forward, Vector3.up) > 0.6f)
			diceCount0 = 1;
		if (Vector3.Dot (-transform.forward, Vector3.up) > 0.6f)
			diceCount0 = 6;
		if (Vector3.Dot (transform.up, Vector3.up) > 0.6f)
			diceCount0 = 5;
		if (Vector3.Dot (-transform.up, Vector3.up) > 0.6f)
			diceCount0 = 2;
		if (Vector3.Dot (transform.right, Vector3.up) > 0.6f)
			diceCount0 = 4;
		if (Vector3.Dot (-transform.right, Vector3.up) > 0.6f)
			diceCount0 = 3;
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dice1_script : MonoBehaviour {
	public int diceCount1;
	public static Dice1_script Instance;

	internal Vector3 initPos;
	// Use this for initialization
	void Start () {
		GetComponent<Rigidbody> ().solverIterations = 250;
		Instance = this;
		initPos = transform.position;
	}

	void OnEnable(){
		initPos = transform.position;
	}

	public int GetDiceCount(){
		diceCount1 = 0;
		regularDiceCount ();
		return diceCount1;
	}

	void regularDiceCount()
	{
		if (Vector3.Dot (transform.forward, Vector3.up) > 0.6f)
			diceCount1 = 1;
		if (Vector3.Dot (-transform.forward, Vector3.up) > 0.6f)
			diceCount1 = 6;
		if (Vector3.Dot (transform.up, Vector3.up) > 0.6f)
			diceCount1 = 5;
		if (Vector3.Dot (-transform.up, Vector3.up) > 0.6f)
			diceCount1 = 2;
		if (Vector3.Dot (transform.right, Vector3.up) > 0.6f)
			diceCount1 = 4;
		if (Vector3.Dot (-transform.right, Vector3.up) > 0.6f)
			diceCount1 = 3;
	}
}

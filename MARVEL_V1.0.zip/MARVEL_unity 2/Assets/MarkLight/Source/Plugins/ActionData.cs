﻿#region Using Statements
using System;
using UnityEngine.EventSystems;
#endregion

namespace MarkLight
{
    /// <summary>
    /// Base class for action data.
    /// </summary>
    public class ActionData
    {
    }
}
